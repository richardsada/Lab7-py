import asyncio

async def process_data_async(data: str) -> int:
 

    words = data.split()
    unique_words = set(word.strip('.,!?;:"').lower() for word in words)
    return len(unique_words)

async def process_multiple_texts(texts: list[str]):
    tasks = [process_data_async(text) for text in texts]
    results = await asyncio.gather(*tasks)  # Асинхронно обрабатываем все тексты
    return results

async def main():
    texts = [
        "adsad sad sad sad sss.",
        "Pssss sss ssss              ssss.",
        "eeeeeeee eeeeeeeee eeee.",
    ]
    unique_counts = await process_multiple_texts(texts)
    for i, count in enumerate(unique_counts, 1):
        print(f"Текст {i}: {count} уникальных слов")


asyncio.run(main())
