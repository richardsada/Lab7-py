import asyncio

async def greet(name: str):
   
    await asyncio.sleep(2) 
    print(f"Привет, {name}!")

async def main():
    names = ["Семен", "Вова", "Виктор"]
    tasks = [greet(name) for name in names]  # Создаем задачи для каждого имени
    await asyncio.gather(*tasks)  # Выполняем задачи одновременно


asyncio.run(main())
